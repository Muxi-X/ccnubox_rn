import GuidePage from '@/module/guide';

export default GuidePage;
