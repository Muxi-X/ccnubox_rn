import LoginPage from '@/module/login';

export default LoginPage;
