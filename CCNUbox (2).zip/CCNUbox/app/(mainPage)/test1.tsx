import React from 'react';

import Text from '@/components/text';

const SamplePage: React.FC = () => {
  return <Text>这里是页面的内容区域</Text>;
};

export default SamplePage;
