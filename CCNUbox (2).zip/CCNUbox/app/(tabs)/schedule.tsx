import CourseTablePage from '@/module/courseTable';

export default CourseTablePage;
