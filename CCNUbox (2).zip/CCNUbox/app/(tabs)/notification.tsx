import NotificationPage from '@/module/notification';

export default NotificationPage;
