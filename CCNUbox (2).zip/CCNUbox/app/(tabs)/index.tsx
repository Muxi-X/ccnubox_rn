import IndexPage from '@/module/mainPage';
export default IndexPage;
