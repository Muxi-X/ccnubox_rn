import SettingPage from '@/module/setting';

export default SettingPage;
