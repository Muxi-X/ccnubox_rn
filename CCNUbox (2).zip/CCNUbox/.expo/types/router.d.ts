/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(mainPage)` | `/(mainPage)/api` | `/(mainPage)/electricityBillBalance` | `/(mainPage)/electricityBillinQuiry` | `/(mainPage)/scoreCalculation` | `/(mainPage)/scoreInquiry` | `/(mainPage)/test1` | `/(mainPage)/test2` | `/(tabs)` | `/(tabs)/` | `/(tabs)/notification` | `/(tabs)/schedule` | `/(tabs)/setting` | `/_sitemap` | `/api` | `/auth` | `/auth/guide` | `/auth/login` | `/electricityBillBalance` | `/electricityBillinQuiry` | `/notification` | `/schedule` | `/scoreCalculation` | `/scoreInquiry` | `/setting` | `/test1` | `/test2`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
