import { geneStyleSheet } from '@/utils/geneStyleSheet';
/** 默认样式 */
export const defaultStyles = geneStyleSheet({
  dark: {},
  light: {},
});
