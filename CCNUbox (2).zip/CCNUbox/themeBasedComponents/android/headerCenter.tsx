const HeaderCenter = () => {
  return <></>;
};

export default HeaderCenter;
