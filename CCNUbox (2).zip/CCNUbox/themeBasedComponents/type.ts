/** 可配置组件名 */
export type ConfigurableComponentName = 'header_left' | 'header_center';
