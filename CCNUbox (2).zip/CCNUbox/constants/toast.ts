export const statusImage = {
  success: require('../assets/images/success.png'),
};
