module.exports = {
  assets: ['node_modules/@ant-design/icons-react-native/fonts'],
};
