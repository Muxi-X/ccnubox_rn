export const JPushSecrets = {
  appKey: '3fdd1ecdd0325fa2a197df7e',
  channel: 'course_box'
}